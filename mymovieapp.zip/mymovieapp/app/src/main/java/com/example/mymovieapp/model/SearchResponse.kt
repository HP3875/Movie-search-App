package com.example.mymovieapp.model

import com.google.gson.annotations.SerializedName

data class SearchResponse(
    @SerializedName("Search") val search: List<Movie>?,
    @SerializedName("Response") val response: String?,
    @SerializedName("Error") val error: String?
)