package com.example.mymovieapp.ui

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.mymovieapp.R
import com.example.mymovieapp.viewmodel.MovieViewModel

class MovieDetailsActivity : AppCompatActivity() {
    private lateinit var movieViewModel: MovieViewModel

    private lateinit var moviePosterImageView: ImageView
    private lateinit var movieTitleTextView: TextView
    private lateinit var movieInfoTextView: TextView
    private lateinit var movieRatingTextView: TextView
    private lateinit var moviePlotTextView: TextView
    private lateinit var goBackButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_details)


        movieViewModel = ViewModelProvider(this).get(MovieViewModel::class.java)


        moviePosterImageView = findViewById(R.id.moviePosterImageView)
        movieTitleTextView = findViewById(R.id.movieTitleTextView)
        movieInfoTextView = findViewById(R.id.movieInfoTextView)
        movieRatingTextView = findViewById(R.id.movieRatingTextView)
        moviePlotTextView = findViewById(R.id.moviePlotTextView)
        goBackButton = findViewById(R.id.goBackButton)


        val imdbId = intent.getStringExtra("IMDB_ID")
        if (imdbId != null) {
            movieViewModel.getMovieDetails(imdbId)
        } else {
            movieTitleTextView.text = "Error: No IMDb ID provided"
        }


        movieViewModel.movieDetails.observe(this) { movie ->
            if (movie != null) {

                movieTitleTextView.text = movie.movieTitle ?: "N/A"


                val year = movie.year ?: "N/A"
                val runtime = movie.runtime ?: "N/A"
                val genre = movie.genre ?: "N/A"
                movieInfoTextView.text = "$year • $runtime • $genre"


                movieRatingTextView.text = movie.imdbRating ?: "N/A"


                moviePlotTextView.text = movie.plot ?: "No plot available."


                if (movie.moviePoster != null && movie.moviePoster != "N/A") {
                    Glide.with(this)
                        .load(movie.moviePoster)
                        .into(moviePosterImageView)
                } else {
                    moviePosterImageView.setImageResource(android.R.drawable.ic_menu_gallery)
                }
            } else {
                movieTitleTextView.text = "Failed to load movie details"
            }
        }


        movieViewModel.errorMessage.observe(this) { error ->
            if (error != null) {
                movieTitleTextView.text = "Error: $error"
            }
        }


        goBackButton.setOnClickListener {
            finish()
        }
    }
}