package com.example.mymovieapp.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.mymovieapp.databinding.ActivityMainBinding
import com.example.mymovieapp.viewmodel.MovieViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var movieViewModel: MovieViewModel
    private lateinit var movieAdapter: MovieAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        movieViewModel = ViewModelProvider(this)[MovieViewModel::class.java]
        movieAdapter = MovieAdapter { imdbId ->
            val intent = Intent(this, MovieDetailsActivity::class.java).apply {
                putExtra("IMDB_ID", imdbId)
            }
            startActivity(intent)
        }

        binding.recyclerView.layoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        binding.recyclerView.adapter = movieAdapter

        binding.searchButton.setOnClickListener {
            val query = binding.searchEditText.text.toString()
            if (query.isNotEmpty()) {
                movieViewModel.searchMovies(query)
            } else {
                Toast.makeText(this, "Please enter a search query", Toast.LENGTH_SHORT).show()
            }
        }

        movieViewModel.movieList.observe(this) { movies ->
            if (movies != null) {
                Log.d("MainActivity", "Movies loaded: ${movies.size}")
                movieAdapter.submitList(movies)
                Toast.makeText(this, "Movies loaded: ${movies.size}", Toast.LENGTH_SHORT).show()
            } else {
                Log.d("MainActivity", "No movies loaded")
                Toast.makeText(this, "No movies loaded", Toast.LENGTH_SHORT).show()
            }
        }

        movieViewModel.errorMessage.observe(this) { error ->
            if (error != null) {
                Log.e("MainActivity", "Error: $error")
                Toast.makeText(this, error, Toast.LENGTH_LONG).show()
            }
        }
    }
}