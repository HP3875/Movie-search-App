package com.example.mymovieapp.viewmodel

import android.annotation.SuppressLint
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mymovieapp.api.ApiClient
import com.example.mymovieapp.api.OmdbApi
import com.example.mymovieapp.model.Movie
import com.example.mymovieapp.model.SearchResponse
import kotlinx.coroutines.launch
import retrofit2.Response

class MovieViewModel : ViewModel() {
    private val _movieList = MutableLiveData<List<Movie>>(emptyList())
    val movieList: LiveData<List<Movie>> get() = _movieList

    private val _movieDetails = MutableLiveData<Movie?>()
    val movieDetails: LiveData<Movie?> get() = _movieDetails

    private val _errorMessage = MutableLiveData<String>()
    val errorMessage: LiveData<String> get() = _errorMessage

    private val omdbApiService: OmdbApi = ApiClient.retrofit.create(OmdbApi::class.java)
    private val apiKey = "187f6eff"  // api key

    @SuppressLint("NullSafeMutableLiveData")
    fun searchMovies(searchQuery: String) {
        viewModelScope.launch {
            try {
                Log.d("MovieViewModel", "Searching movies with query: $searchQuery")
                val response: Response<SearchResponse> = omdbApiService.searchMovies(searchQuery, apiKey)
                if (response.isSuccessful) {
                    val searchResponse = response.body()
                    Log.d("MovieViewModel", "Search response: $searchResponse")
                    if (searchResponse?.response == "True" && searchResponse.search != null) {
                        _movieList.value = searchResponse.search
                    } else {
                        _errorMessage.value = searchResponse?.error ?: "No movies found"
                        _movieList.value = emptyList()
                    }
                } else {
                    _errorMessage.value = "HTTP Error: ${response.message()} (Code: ${response.code()})"
                    _movieList.value = emptyList()
                }
            } catch (e: Exception) {
                Log.e("MovieViewModel", "Network Error: ${e.message}", e)
                _errorMessage.value = "Network Error: ${e.message}"
                _movieList.value = emptyList()
            }
        }
    }

    fun getMovieDetails(imdbId: String) {
        viewModelScope.launch {
            try {
                Log.d("MovieViewModel", "Fetching details for IMDb ID: $imdbId")
                val response: Response<Movie> = omdbApiService.getMovieDetails(imdbId, apiKey)
                if (response.isSuccessful) {
                    val movieDetail = response.body()
                    Log.d("MovieViewModel", "Movie detail response: $movieDetail")
                    if (movieDetail?.response == "True") {
                        _movieDetails.value = movieDetail
                    } else {
                        _errorMessage.value = movieDetail?.error ?: "Movie not found"
                        _movieDetails.value = null
                    }
                } else {
                    _errorMessage.value = "HTTP Error: ${response.message()} (Code: ${response.code()})"
                    _movieDetails.value = null
                }
            } catch (e: Exception) {
                Log.e("MovieViewModel", "Network Error: ${e.message}", e)
                _errorMessage.value = "Network Error: ${e.message}"
                _movieDetails.value = null
            }
        }
    }
}