package com.example.mymovieapp.model

import com.google.gson.annotations.SerializedName

data class Movie(
    @SerializedName("Title") val movieTitle: String?,
    @SerializedName("Poster") val moviePoster: String?,
    @SerializedName("imdbID") val movieImdbID: String?,
    @SerializedName("Response") val response: String?,
    @SerializedName("Error") val error: String?,
    @SerializedName("Year") val year: String?,
    @SerializedName("Runtime") val runtime: String?,
    @SerializedName("Genre") val genre: String?,
    @SerializedName("imdbRating") val imdbRating: String?,
    @SerializedName("Plot") val plot: String?
)