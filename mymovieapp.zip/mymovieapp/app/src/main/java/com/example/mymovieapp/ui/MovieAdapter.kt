package com.example.mymovieapp.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.mymovieapp.R
import com.example.mymovieapp.model.Movie

class MovieAdapter(
    private val onItemClick: (String) -> Unit
) : ListAdapter<Movie, MovieAdapter.MovieViewHolder>(MovieDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.movie_item, parent, false)
        return MovieViewHolder(view)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = getItem(position)
        holder.bind(movie)
    }

    inner class MovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val movieTitleTextView: TextView = itemView.findViewById(R.id.movieTitleTextView)
        private val moviePosterImageView: ImageView = itemView.findViewById(R.id.moviePosterImageView)

        fun bind(movie: Movie) {
            movieTitleTextView.text = movie.movieTitle ?: "N/A"
            if (movie.moviePoster != null && movie.moviePoster != "N/A") {
                Glide.with(itemView.context)
                    .load(movie.moviePoster)
                    .into(moviePosterImageView)
            } else {
                moviePosterImageView.setImageResource(android.R.drawable.ic_menu_gallery) // Fallback image
            }
            itemView.setOnClickListener {
                movie.movieImdbID?.let { imdbId ->
                    onItemClick(imdbId)
                }
            }
        }
    }
}

class MovieDiffCallback : DiffUtil.ItemCallback<Movie>() {
    override fun areItemsTheSame(oldItem: Movie, newItem: Movie): Boolean {
        return oldItem.movieImdbID == newItem.movieImdbID
    }

    override fun areContentsTheSame(oldItem: Movie, newItem: Movie): Boolean {
        return oldItem == newItem
    }
}